@echo off
if exist "%~dp0..\SuraSetup.exe" (
  "%~dp0..\SuraSetup.exe" %*
) else (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0SuraSetup-GUI.ps1" %*
)