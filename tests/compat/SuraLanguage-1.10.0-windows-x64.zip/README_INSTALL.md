# Sura Language Windows Installer

This package installs Sura Language as a normal per-user language runtime.

## GUI Install

Normal users should download and double-click the single-file installer:

```text
SuraLanguageSetup-1.10.0.exe
```

That one file extracts its internal installer kit, opens the setup window, and cleans up the temporary files after setup exits. The setup window shows required disk space, the installation actions, install path selection, and the user PATH option.

The folder installer entry point below is for developers and release verification:

```text
dist\SuraLanguage-windows-x64\SuraSetup.exe
```

The `payload` and `support` folders are installer internals.

## Command-Line Install

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\support\SuraSetup.ps1
```

The installer copies the Sura Language engine and `surapkg.exe` to:

```text
%LOCALAPPDATA%\Programs\Sura\bin
```

It also creates `sura.cmd` and `surapkg.cmd`, then adds the bin directory to the user PATH. Open a new terminal after installation.

## Use

```powershell
sura app.sura
sura --repl
surapkg init my_app
```

No Python, Node.js, CMake, or compiler is required for normal Sura scripts. Those tools are only needed for optional developer features such as Python interop, JavaScript/WASM target tests, native plugins, embedding, or benchmarks.

## Uninstall

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\support\SuraSetup.ps1 -Uninstall
```